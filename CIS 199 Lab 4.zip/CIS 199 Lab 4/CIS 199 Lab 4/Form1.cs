﻿//Zach Jones
//9/22/2024
//CIS 199 Lab 4
//9/29/2024
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS_199_Lab_4
{
    public partial class Form1 : Form
    {
        //keep track and accept and reject counts
        private int ACCEPT_COUNT = 0;
        private int REJCT_COUNT = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Collect constant variables
            const double MAX_GPA = 4.0;
            const double MIN_GPA = 0.0;
            const double THRESH_HOLD = 3.0;
            const int MIN_SCORE = 0;
            const int THRESH_SCORE = 60;
            const int MAX_SCORE = 100;
            //collect variables from GPA and SCORE
            double GPA;
            int ADMISSION;
            //parse the GPA
            if (double.TryParse(GPABox.Text, out GPA) && GPA >= MIN_GPA && GPA <= MAX_GPA)
            {
                //Parse the test score
                if (int.TryParse(AdmissionBox.Text, out ADMISSION) && ADMISSION >= MIN_SCORE && ADMISSION <= MAX_SCORE)
                {
                    //Formula for the Admission descision. 
                    if ((GPA >= THRESH_HOLD && ADMISSION >= THRESH_SCORE) || (GPA < THRESH_HOLD && ADMISSION >= 80))
                    {
                        //Display Accept in the textbox
                        DescisionBox.Text = "Accept";
                        ACCEPT_COUNT ++;
                    }
                    else
                    {
                        //Display Reject in the textbox
                        DescisionBox.Text = "Reject";
                        REJCT_COUNT ++;
                    }
                    //Update the totals
                    ACCBox.Text = ACCEPT_COUNT.ToString();
                    RJCBox.Text = REJCT_COUNT.ToString();
                }
                else
                {   //Make sure to enter a proper test score value
                    MessageBox.Show("Please enter a valid test score between 0 and 100.");
                }
                }
                else
                {   //Make sure to enter a proper GPA value
                    MessageBox.Show("Please enter a valid GPA between 0.0 and 4.0.");
                }
        }
    }
      
}
