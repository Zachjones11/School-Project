﻿namespace CIS_199_Lab_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GPABox = new System.Windows.Forms.TextBox();
            this.AdmissionBox = new System.Windows.Forms.TextBox();
            this.DescisionBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ACCBox = new System.Windows.Forms.TextBox();
            this.RJCBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter your GPA (0.0-4.0):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(331, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Test Score (0-100):";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(292, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Admission Descision: ";
            // 
            // GPABox
            // 
            this.GPABox.Location = new System.Drawing.Point(452, 79);
            this.GPABox.Name = "GPABox";
            this.GPABox.Size = new System.Drawing.Size(128, 38);
            this.GPABox.TabIndex = 3;
            // 
            // AdmissionBox
            // 
            this.AdmissionBox.Location = new System.Drawing.Point(452, 160);
            this.AdmissionBox.Name = "AdmissionBox";
            this.AdmissionBox.Size = new System.Drawing.Size(128, 38);
            this.AdmissionBox.TabIndex = 4;
            // 
            // DescisionBox
            // 
            this.DescisionBox.Location = new System.Drawing.Point(452, 235);
            this.DescisionBox.Name = "DescisionBox";
            this.DescisionBox.ReadOnly = true;
            this.DescisionBox.Size = new System.Drawing.Size(128, 38);
            this.DescisionBox.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(234, 308);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(134, 60);
            this.button1.TabIndex = 6;
            this.button1.Text = "Admit?";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 394);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 32);
            this.label4.TabIndex = 7;
            this.label4.Text = "Accpeted:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 445);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 32);
            this.label5.TabIndex = 8;
            this.label5.Text = "Rejected:";
            // 
            // ACCBox
            // 
            this.ACCBox.Location = new System.Drawing.Point(452, 391);
            this.ACCBox.Name = "ACCBox";
            this.ACCBox.ReadOnly = true;
            this.ACCBox.Size = new System.Drawing.Size(128, 38);
            this.ACCBox.TabIndex = 9;
            // 
            // RJCBox
            // 
            this.RJCBox.Location = new System.Drawing.Point(452, 445);
            this.RJCBox.Name = "RJCBox";
            this.RJCBox.ReadOnly = true;
            this.RJCBox.Size = new System.Drawing.Size(128, 38);
            this.RJCBox.TabIndex = 10;
            // 
            // Form1
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 519);
            this.Controls.Add(this.RJCBox);
            this.Controls.Add(this.ACCBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.DescisionBox);
            this.Controls.Add(this.AdmissionBox);
            this.Controls.Add(this.GPABox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox GPABox;
        private System.Windows.Forms.TextBox AdmissionBox;
        private System.Windows.Forms.TextBox DescisionBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ACCBox;
        private System.Windows.Forms.TextBox RJCBox;
    }
}

